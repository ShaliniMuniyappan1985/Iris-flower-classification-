
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Flower, Brain, BarChart3, Info } from "lucide-react";
import { toast } from "sonner";

interface IrisData {
  sepalLength: number;
  sepalWidth: number;
  petalLength: number;
  petalWidth: number;
}

interface PredictionResult {
  species: string;
  confidence: number;
  description: string;
  characteristics: string[];
}

const Index = () => {
  const [measurements, setMeasurements] = useState<IrisData>({
    sepalLength: 0,
    sepalWidth: 0,
    petalLength: 0,
    petalWidth: 0
  });

  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isClassifying, setIsClassifying] = useState(false);

  const classifyIris = (data: IrisData): PredictionResult => {
    const { sepalLength, sepalWidth, petalLength, petalWidth } = data;
    if (petalLength < 2.5 && petalWidth < 1.0) {
      return {
        species: "Iris Setosa",
        confidence: 0.95,
        description: "The smallest and most distinct of the three iris species",
        characteristics: ["Small petals", "Compact flowers", "Often found in cooler climates"]
      };
    } else if (petalLength >= 2.5 && petalLength < 5.0 && petalWidth >= 1.0 && petalWidth < 1.8) {
      return {
        species: "Iris Versicolor",
        confidence: 0.87,
        description: "Medium-sized iris with balanced proportions",
        characteristics: ["Medium petals", "Balanced flower structure", "Adaptable to various environments"]
      };
    } else {
      return {
        species: "Iris Virginica",
        confidence: 0.92,
        description: "The largest of the three iris species",
        characteristics: ["Large petals", "Tall stems", "Robust flowers"]
      };
    }
  };

  const handleInputChange = (field: keyof IrisData, value: string) => {
    const numValue = parseFloat(value) || 0;
    setMeasurements(prev => ({
      ...prev,
      [field]: numValue
    }));
  };

  const handleClassify = async () => {
    if (measurements.sepalLength === 0 || measurements.sepalWidth === 0 || 
        measurements.petalLength === 0 || measurements.petalWidth === 0) {
      toast.error("Please enter all measurements");
      return;
    }

    setIsClassifying(true);

    setTimeout(() => {
      const result = classifyIris(measurements);
      setPrediction(result);
      setIsClassifying(false);
      toast.success(`Classified as ${result.species}!`);
    }, 1500);
  };

  const resetForm = () => {
    setMeasurements({
      sepalLength: 0,
      sepalWidth: 0,
      petalLength: 0,
      petalWidth: 0
    });
    setPrediction(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50">
      {/* UI code here - truncated for brevity */}
    </div>
  );
};

export default Index;
